import React from "react";
import styles from "./MobileApp.module.css";

const MobileApp = () => {
  return <div className={styles.mainContainer}></div>;
};

export default MobileApp;
